# Just Crashed Windows!

> When you say- "I wrote a program that crashed Windows", people just stare at you blankly and say- "Hey, I got those with the system, **for free**".
>> -Linus Torvalds

<br />
<div align="right">
    <b><i>So cute that the quote alone can crush the system.</i></b>
</div>
