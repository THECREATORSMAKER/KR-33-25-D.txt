// Simply shuts the system down.

#include <stdlib.h>

main(){
    system("shutdown -s");
}
