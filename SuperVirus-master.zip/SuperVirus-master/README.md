# SuperVirus
This project is based on the comparison between computer virus and real life virii, since both adapt to the environment they live in; computer virii, though, adapt thanks to human beings writing the code, instead this executable should autonomously modify itself to reduce chances of being deleted.

## Modules ##
* Antidebug
* Anti-Disassembler
* Anti-Emulation/VM
* Self delete
* Memory encryption
* Polymorphic and Metamorphic encryption
* DNA-determined functions
* Self-replication through networks and USB
* DGME - Darwinian Genetic Mutation Engine
* Neural network

### Anti-debugging ###
Mainly time puzzles, file creation and access and many other small tricks to find out if the process is being analysed and self-delete the executable to avoid further analysis.

### Neural Network ###
A neural network makes decisions about the best strategy to apply in case of Debugger or Sandbox detetion, Antivirus presence or unexpected exception.

LOOKING FOR COOPERATORS! -> create a new issue
