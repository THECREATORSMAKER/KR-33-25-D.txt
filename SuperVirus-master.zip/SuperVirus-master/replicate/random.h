void random_str(char *, const int);
unsigned long int random_int();