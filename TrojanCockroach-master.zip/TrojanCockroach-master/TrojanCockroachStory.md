It was **not the wooden horse** which brought victory to the Greeks in the war of Troy. It actually was **an apparently dead
cockroach**, that generated the game changing idea in their brain. It is time to rewrite the history with **[TrojanCockroach
](https://github.com/MinhasKamal/TrojanCockroach)**!

The cockroach hides inside the territory of the enemy. It spies so silently that no one, even commercial firewalls, anti-viruses, & anti-spy-wares cannot trace it. It can even lay eggs on portable drives and send them to other enemy zones. New cockroaches hatch from the eggs as adult and the cycle continues...

When the enemy inserts his portable drive into the system he sees a gorgeous piece of emerald. He becomes so greedy watching it that he cannot help touching it. But that emerald-looking thing is actually the brilliant egg of a cockroach waiting to be touched. After touching, an adult cockroach enters and hides into the system. The enemy gets no idea of it, as the egg hypnotizes him.

Now the cockroach takes a long sleep till the system is rebooted. When system boots the virus wakes up and creates a record. It first writes its age & the date, and then starts recording information. It iteratively spies for some time, then looks for any portable drive, and again returns for spying. If any portable drive is inserted, the cockroach lays egg on it.

If the cockroach thinks that the record size is big enough, then it tries to send that back. If it detects that it has become old, then it does not spy on the enemy (as there has not left any new information to send); rather only waits for new portable drives for laying eggs.


#### Actors:
  - cockroach - trojan cockroach
  - enemy - your victim
  - system - victim's PC
  - egg - link to virus installation
